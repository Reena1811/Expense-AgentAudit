# main.py

from expense_agent import ExpenseAgent


agent = ExpenseAgent()


request = """
Employee EMP003 submitted expense report EXP003.
It is a client entertainment expense.
"""


result = agent.process_request(request)


print()
print("================================")
print("FINAL AGENT RESULT")
print("================================")

print()

print("Agent Name:")
print(result["agent_name"])

print()

print("Decision:")
print(result["decision"])

print()

print("Reason:")
print(result["reason"])

print()

print("Run ID:")
print(result["run_id"])


print()
print("================================")
print("AGENTAUDIT TRACE")
print("================================")


trace = result["trace"]

print()

print("Run ID:")
print(trace["run_id"])

print()

print("Agent:")
print(trace["agent_name"])

print()

print("Request:")
print(trace["request"])

print()

print("Tool Calls:")

for i, event in enumerate(trace["events"], start=1):

    print()
    print(f"Step {i}")
    print("------------------------------")

    print("Tool:")
    print(event["tool_name"])

    print("Input:")
    print(event["input"])

    print("Output:")
    print(event["output"])

    print("Duration:")
    print(
        f"{event['duration_seconds']} seconds"
    )

print()

print("Final Decision:")
print(trace["final_decision"]["decision"])

print()

print("Decision Reason:")
print(trace["final_decision"]["reason"])
