import os
from dotenv import load_dotenv
from openrouter import OpenRouter

load_dotenv()

client = OpenRouter(
    api_key=os.getenv("OPENROUTER_API_KEY")
)

response = client.chat.send(
    model="openrouter/free",
    messages=[
        {
            "role": "user",
            "content": "Explain what an expense reimbursement policy is in one sentence."
        }
    ],
    stream=False
)

print(response.choices[0].message.content)
